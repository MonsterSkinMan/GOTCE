# Join our discord server!
Join the BALLS group discord server for gotce and wrb discussion, as well as to just hang out with some based people in general https://cutt.ly/ballscord

# GOTCE ost
WOOOOOO GOTCE OST BABY GOTCE SWEEP https://www.youtube.com/playlist?list=PL1ARQQc-u7IEcRc1s8x8TSrVwUA0sQ0rX

# Gamers of the Cracked Emoji
Are you tired of your runs being too same-y? Tired of the anemically bad balance of RoR2? Wish there were some interesting new items to spice up your runs? Want to die?

Well then, GOTCE has you covered. As it stands, it has the most items out of any item mod, and also more than sotv, all of it in glorious shitpost fashion. It also has more enemies than any mod, 12 alternate skills, a new elite type, and an all new survivor! It even has actual lore that's explained in logbooks and shit, unlike Survivors of the Void. Hell, we even expanded upon the void lore!

# The Contentfunder (so far)
| Icon | Name | Description |
|---|---|---|
|  | --- |  |
|  | Common Items |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1126616397070471168/DividedBy.png" width="100"/> | / | Every 2 minutes and 20 seconds, swap between a movement speed boost and a movement speed debuff alongside an armor boost. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111026628657232/AnimalHead.png" width="100"/> | Animal Head | 'Critical Strikes' reduce ability cooldowns. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1050863497908592650/Balls.png" width="100"/> | Balls | They will stay. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111026980982794/BangSnap.png" width="100"/> | Bang Snap | +2 AOE effect to all explosions. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1050872426831020092/BarrierInsurance.png" width="100"/> | Barrier Insurance | Gain an amount of barrier at the start of each stage based on how many barrier items you have. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111027379445841/Barrierworks.png" width="100"/> | Barrierworks | Activating an interactable grants a temporary barrier. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1126604715451502633/BentCrutch.png" width="100"/> | Bent Crutch | Gain a small chance to cheat death. Increase all stats upon dying. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1162687768271519784/BoneArmour.png?ex=655887dd&is=654612dd&hm=b8f0aec9bb3b847f465759b716ed969b9cace1ec0e909524f0840bf12522a0c1&>" width="100"/> | Bone Armour | Gain +1 armor and lose 1% max health. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1162758316733239426/BloodyShank.png?ex=6558c991&is=65465491&hm=466d1e4fe8ddd6fa28e9b99978ff7183cea0ac7348e397d443a15a09aab849ad&" width="100"/> | Bloody Shank | Gain +5% bleed and crit chance. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111028121833483/ChaosRounds.png" width="100"/> | Chaos Rounds | Chance to fire a random projectile when attacking. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1048370714480226344/ChristmasGift.png" width="100"/> | Christmas Gift | If the month is December, gain 3 random items on pickup, after which the item is consumed. Does nothing otherwise. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1162687747954315284/DrippingCamera.png?ex=655887d8&is=654612d8&hm=d4a10b2ea3320979b0f8eabc8d9245a0f1743cc8deb7f6d3b695f28d9aec796a&" width="100"/> | Dripping Camera | Gain a chance to critically camera rotate, spinning your camera to the right. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1050880830148444220/EmpathyC4.png" width="100"/> | Empathy C4 | Gain |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111028507713536/FaultySpacetimeClock.png" width="100"/> | Faulty Spacetime Clock | Gain a chance to critically Stage Transition, skipping the next stage and unlocking powerful synergies... |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111028860026900/GD1Nullified.png" width="100"/> | \#gd1-nullified | 'Critical Strikes' poison enemies. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1045830522292674682/GummyVitamins.png" width="100"/> | Gummy Vitamins | Gain a chance to 'critically sprint', doubling your sprinting speed. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111029199781981/HealingScrap.png" width="100"/> | Healing Scrap | Prioritized when used with Common 3D Printers. Usable once per stage. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1201949272510320731/LeviathanLarva.png?ex=65cbad7d&is=65b9387d&hm=2ec29d45a5d88eff03c1849c1fd7b56f6fd31a2f0f0ddc72f17da0a39ef266af&=&format=webp&quality=lossless" width="100"/> | Leviathan Larva | Critical strikes deal more damage for every shield category item in your inventory. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1046378216442560592/LuckiestMask.png" width="100"/> | Luckiest Mask | Increase proc coefficients. Breaks at low health. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111029556289546/Lunch.png" width="100"/> | Lunch | If it's lunch time, gain 10% max health. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111029933781002/MoldySteak.png" width="100"/> | Moldy Steak | Lose 25 max health. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111318833238066/PogoStick.png" width="100"/> | Pogo Stick | Increase jump height. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1203420610420674621/Personal_Shield_Generator_Unteired.png?ex=65d107c7&is=65be92c7&hm=78572a3adc22482136a59b18d2819398beb4cf31af0f4c7554a17a36559a2ad8&=&format=webp&quality=lossless" width="100"/> | Personal OSP Generator | Increases One Shot Protection threshold and invincibility frames. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1131046568980648016/Personal_Shield_Generator.png" width="100"/> | Personal Shield Generator | gain 8% of yrou max hp in shield |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1048320358014537778/RoR2Discussion.png" width="100"/> | \#ror2-discussion | On 'critical sprint', your attacks inflict blight for a short duration. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1201967654693240892/SeethingOpioids.png?ex=65cbbe9c&is=65b9499c&hm=10bfbfffc8dda8d9674361316b6de6a74eb94aedfe758374dd036a682b27b544&=&format=webp&quality=lossless" width="100"/> | Seething Opioids | Gain a flat amount of shield that increases for each Shield category item you have. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1046379853416501298/SigmaGrindset.png" width="100"/> | Sigma Grindset | On sprint crit, permanently increase your regeneration. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111319227498536/SkullKey.png" width="100"/> | :Skull: Key | 'Critical Stage Transitions' give you 5 powerful items. Not consumed on use. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1126607967089852568/SkullReaction.png" width="100"/> | Skull Reaction | Gain a chance to critically die, causing you to die twice upon death. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1171229998426894428/SmallSpinny.png?ex=655bebf0&is=654976f0&hm=b331cb05fb760f2e7f4d89d7b40ffdbe4a9b8c6213ad7cf1aa4fead79dfef69d&" width="100"/> | Small Spinny | Gain a temporary attack speed boost on camera rotation crit. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1162694531267952660/SummertimeSoda.png?ex=65588e2a&is=6546192a&hm=d22142e6f21f355b3888a0298dfaf709caaa1a035cbebef1a2df7adecee176d3&" width="100"/> | Summertime Soda | Gain extra shield, damage reduction, and max HP if the current season is summer in the Northern Hemisphere. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1190030815632048138/TeachersPet.png?ex=65c53b90&is=65b2c690&hm=64c2d93e061eb6bb1e4865e27f42f055add99701666e4c23ea196da449edd26b&=&format=webp&quality=lossless" width="100"/> | Teacher's Pet | Gain a 20% damage boost if the survivor you are playing as has the letter A in their name. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111319714050048/TuesdayMagazine.png" width="100"/> | Tuesday Magazine | Increases your secondary charges if it's Tuesday. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1050893366734368898/TurbulentDefibrillator.png" width="100"/> | Turbulent Defibrillator | Gain a small chance to cheat death. Increase attack speed upon dying. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1131033045168832552/WeepingAegis.png" width="100"/> | Weeping Aegis | Killing a bleeding enemy permanently increases your shield. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1048379443426631740/WhiteFragment.png" width="100"/> | White Fragment | Does nothing. 2 stacks combine into 4 random items. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111320200577084/ZoomLenses.png" width="100"/> | Zoom Lenses | Gain a chance to periodically 'FOV Crit', zooming in your vision. |
|  | --- |  |
|  | Uncommon Items |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1131069477858058322/0Pebbles.png" width="100"/> | 0 Pebbles | Gain 0 Pebbles. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053326276418601001/Aegiscentrism.png" width="100"/> | Aegiscentrism | Gain multiple orbital aegis that periodically grant temporary barrier. Every minute, assimilate another item into Aegiscentrism. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053337486736232550/AemergencyAegis.png" width="100"/> | Aemergency Aegis | For every backup magazine in your inventory, all sources of barrier grant increased barrier. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111320657772595/AmalgamSpoon.png" width="100"/> | Amalgam Spoon | Killing an elite enemy with a 'Critical Strike' grants a temporary barrier based on secondary charges. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111321144299560/AmberRabbit.png" width="100"/> | Amber Rabbit | On 'Stage Transition Crit', double your item count exponentially. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034118824343117975/AnalyticalAegis.png" width="100"/> | Analytical Aegis | Gain a miniscule temporary barrier on 'FOV Crit'. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1162745940554297344/BillieJean.png?ex=6558be0b&is=6546490b&hm=cb75d0d7bde77985b2bdffd8bae88d501797c6731225dc7bd1d6c930af8b2aff&" width="100"/> | Billie Jean | Moonwalk. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1046389011930951750/BoxingGloves.png" width="100"/> | Boxing Gloves | Knock enemies back on hit. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111321576329266/DecorativeDrill.png" width="100"/> | Decorative Drill | 'Critical Strikes' grant a temporary barrier. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111321983160320/DelicaterWatch.png" width="100"/> | Delicater Watch | Deal increased damage. Breaks upon activating the teleporter. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1131033045466619964/ExtremelyUnstableTeslaCoil.png" width="100"/> | Extremely Unstable Tesla Coil | Rapidly shock all enemies with extremely weak lightning. Super fucking laggy. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1162702692704067614/FrenchHorn.png?ex=655895c3&is=654620c3&hm=b6c66a3c62fb572a870981e33b175b53304d18dba2b436971356edacfcfcbbf0&" width="100"/> | French Horn | Activating your equipment gives you a burst of movement speed. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1131033043872784517/Gasogreen.png?ex=65541d1b&is=6541a81b&hm=6500469b27e1b25583fbc0feac4bcb9045b7aabb66f5830114108724e77aa755&=" width="100"/> | Gasogreen | Killing an enemy damages and weakens other nearby enemies. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111322390003743/GrandfatherClock.png" width="100"/> | Grandfather Clock | On 'Stage Transition Crit', die. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111322918502510/heartybreakfast.png" width="100"/> | Hearty Breakfast | On 'Stage Transition Crit', gain a temporary barrier. Consumed on use. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051121333037187173/HIFUsRacecar.png" width="100"/> | HIFU's Racecar | Reduce Secondary skill cooldown. On 'Sprint Crit', instantly recharge all charges of your secondary skill. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1122841516994474004/LeechingGuillotine.png" width="100"/> | Leeching Guillotine | Dealing damage heals you a little bit. Instantly kill very low health Elite monsters. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1163853374630924470/LtGMk1.png?ex=65538aeb&is=654115eb&hm=92d8970fbf790f5e2f7901f96f6fbdd0a04d6fc36386b9ff0b9a70a253c57214&" width="100"/> | LtG Mk. 1 | Love yourself, now! |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1201956311546204170/LuckyDay.png?ex=65cbb40b&is=65b93f0b&hm=5d1f21e5c9792156cc9f7034baf5d42355a317fb589956211b4e51da23c2fc3b&=&format=webp&quality=lossless" width="100"/> | Lucky Day | Gain a chance to cheat death. Upon dying, increase all crit type chances. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051115451775729755/MissileGuidanceSystem.png" width="100"/> | Missile Guidance System | On 'Critical FOV Strike', fire a homing missile. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1163056414143553566/OPMercBuild.png?ex=6559df31&is=65476a31&hm=05f7d567a2d198ac20672022d98b8d11ecf160ff736e857cbaf30f4f3d07c062&" width="100"/> | OP Merc Build | Become briefly invincible every second. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1162846169723060396/Retrobauble.png?ex=65591b63&is=6546a663&hm=306a8156e1c28955a62744b4409a1eabb4c7ffad58499eca5f4648f1badfa144&" width="100"/> | Retrobauble | It's literally just CU0 chronobauble. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1163857649889202196/ScathingEmbrace.png?ex=65538ee7&is=654119e7&hm=743f3fee5a739565397d4463f4e7587deea9ab59452bce9700b6a2e7873a9aa6&" width="100"/> | Scathing Embrace | Increase armor and movement speed on camera rotation crit.
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111564426526791/SpafnarsFries.png" width="100"/> | Spafnar's Fries | Gain +50% max health. #JusticeForSpafnar. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1163065212593770576/SpeedyFinger.png?ex=6559e763&is=65477263&hm=6363ad88dfe89316cc4319ebd15cf8dafd894a8604e180ff4c56c31472df30f2&" width="100"/> | Speedy Finger | Increased attack speed for every secondary charge you have. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1201964983156473887/SquidInkSpaghetti.png?ex=65cbbc1f&is=65b9471f&hm=2fbf41c97ad0a31b56cd14937eae976b1803b6257dc82b1cf74cc525bb079e00&=&format=webp&quality=lossless" width="100"/> | Squid Ink Spaghetti | 'Critical Stage Transitions' reveal nearby interactables. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1163061719116042372/TrickledownBleedonomics.png?ex=6559e422&is=65476f22&hm=a5b5896b1c9cb579b1404deb0c3e6037ab55aa189f29126b4d2385d96cfa02cb&" width="100"/> | Trickle-down Bleedonomics | Your bleed has a proc coefficient.
|  | --- |  |
|  | Legendary Items |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051508487554879508/AegisDisplayCase.png" width="100"/> | Aegis Display Case | Halve barrier decay rate. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111564841766994/bottledcommand.png" width="100"/> | Bottled Command | Gain 2 stacks of every vanilla S Tier green item. Have fun. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111565185679380/bottledenigma.png" width="100"/> | Bottled Enigma | Rapidly triggers random Equipment effects. Gain 26 max health. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1190041047540178966/EternalEcho.png?ex=65c54517&is=65b2d017&hm=1fee108c9c154583607eebd1e62182d99d3bf07b2324cb48d83a66866969bb61&=&format=webp&quality=lossless" width="100"/> | Eternal Echo | Attacks hit an additional time for slightly less damage. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111565814829108/FreeWiFi.png" width="100"/> | Free WiFi | Unlock orbital skills in hidden realms. Instantly die if picked up again. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034120103891042304/GabesShank.png" width="100"/> | Gabe's Shank | Gain bonus damage for every game you have installed on Steam. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111566162972732/Galsone.png" width="100"/> | Galsone | I'm galsone! |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1131033043587579935/GalsoneSteak.png" width="100"/> | Galsone Steak | +25 AOE effect. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051500697327239189/Gamepad.png" width="100"/> | Gamepad | Increase 'Sprint Crit' chance based on your inputs per second. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053401235329392722/GenevaSuggestion.png" width="100"/> | Geneva Suggestion | War crimes make you stronger. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111566506885131/HelloWorld4.png" width="100"/> | Hello World | Double your common items at a price... |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1190037314093727826/ImpostersBlade.png?ex=65c5419d&is=65b2cc9d&hm=8a79bf5a6d31e8d856df60ffee588fdb5078fb6f77a56db8cd08861918d8d70f&=&format=webp&quality=lossless" width="100"/> | Imposter's Blade | Teleport forward after killing an elite. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111566867599432/Kirn.png" width="100"/> | Kirn | Even if frags did 2000% with no falloff I'd still use suppressive because I value survivability and consistency more than anything. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1171231152669982741/Lotus.png?ex=655bed03&is=65497803&hm=47c01e46541631fefd66f7750f43861e2cc555d2aacc5df5e5caf3e6738b563e&" width="100"/> | Lotus | Permanently increase your max health upon taking damage. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1163853680395694173/LtGMk2.png?ex=65538b34&is=65411634&hm=dfc0fc9488c89332d20b90968429f42c0e551a580428a18465fee5f2fcc10df1&" width="100"/> | LtG Mk. 2 | Keep yourself safe. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1171225908657537084/OniHuntersSword.png?ex=655be820&is=65497320&hm=0c112e759d70dea5e9909b9dcc5c0d2c3f47a413ada5951f407131adb0bbbcbf&" width="100"/> | Oni Hunter's Sword | Chance for lunar items to be converted into red items on pickup. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051496085874556998/PierReviewedSource.png" width="100"/> | Pier-Reviewed Source | I don't fucking think so. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1131033044556456047/psg13.png" width="100"/> | Personal Shield Generator (13) | videogame won |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1131052482164949114/sscnft.png" width="100"/> | Spikestrip Chan NFT | Increases a random stat. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111567626764359/TubOfLard.png" width="100"/> | Tub Of Lard | Gain a lot of maximum health and armor. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051492679738986648/UltraInstinctAegis.png" width="100"/> | Ultra Instinct Aegis | Landing a 'Critical Strike' shortly after taking heavy damage grants temporary barrier. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1171226979266207764/ZaniestTree.png?ex=655be920&is=65497420&hm=8afb2b4c3b5915dc0d4465617733b515ed4864d3f4b9758a7a32878ea64d4c04&" width="100"/> | Zaniest Tree | If you're over 25 and own a computer, this game is a must-have! |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111568075571220/ZanySoup.png" width="100"/> | Zany Soup | Triple the amount of food-related items you have. |
|  | --- |  |
|  | Boss Items |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111710224728104/NeverEndingAgony.png" width="100"/> | Never Ending Agony (Gup) | Gup is not a funny meme shut the fuck up. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051487459525021827/RightRingFingerOfProvidence.png" width="100"/> | Right Ring Finger of Providence (Providence) | Double ALL of your stats. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111710631579658/ViscousBlast.png" width="100"/> | Viscous Blast (Jellyfish) | Emit a devastating explosion on death. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051490767987802214/WoolBlanket.png" width="100"/> | Wool Blanket (Crowdfunder Woolie) | Your damage scales off of the quality of your items, according to Woolie... |
|  | --- |  |
|  | Lunar Items |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111711139086426/BackupHammer.png" width="100"/> | Backup Hammer | Gain extra secondary charges... BUT you can only use your secondary skill. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111711529140254/BigShoe.png" width="100"/> | Big Shoe | "Reduce" the proc coefficient of all your attacks to 3.0... EVEN if they are normally higher. Yes, this affects the proc coefficient of EVERYTHING. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053375221203214448/Conformity.png" width="100"/> | Conformity | Gain increased attack speed... BUT you transfrom into the enemy on hit. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111711940190208/CorruptedShard.png" width="100"/> | Corrupted Shard | Seems to do nothing... BUT seems to do nothing... |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111712368001074/CrownPrince.png" width="100"/> | Crown Prince | Cheat death, but you die in a single hit... Breaks after 50 uses |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053365142252953640/DarkFluxPauldron.png" width="100"/> | Dark Flux Pauldron | Double your attack speed... BUT double your cooldowns. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111712795836616/DopeDope.png" width="100"/> | Dope Dope | Your base damage is converted into attack speed. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053380765875965972/EntropicEmblem.png" width="100"/> | Entropic Emblem | Delete nearby enemies and projectiles... BUT delete nearby interactables and allies as well. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111713190092951/HuntressHarpoon.png" width="100"/> | Huntress Harpoon | Gain extra utility charges and movement speed, but greatly reduce your damage. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111713655664700/MemoriesOfMisery.png" width="100"/> | Memories Of Misery | Increase your move speed... BUT invert your controls. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111714096058388/MonstersVisage.png" width="100"/> | Monster's Visage | Deal double damage to nearby enemies... BUT deal halved damage to enemies outside the radius. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111927531614259/PaleAle.png" width="100"/> | Pale Ale | Increase your damage... BUT majorly fuck up everyone's vision. Currently host only :( |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1171228549269704774/PebbsiShaker.png?ex=655bea96&is=65497596&hm=086a3049f9bd874bcdf9ec0fa34feaa683b4ea8feaf9d0bacab59df6d7f30454&" width="100"/> | Pebbsi Zero | Become the roy :blueberries: |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1190025400106111056/PurpleWhip.png?ex=65c53684&is=65b2c184&hm=f1f4497df3783e9cfa1521dbd2708f7321c7fd00411b89fb615444d1ce8f8d21&=&format=webp&quality=lossless" width="100"/> | Purple Whip | Your movement speed is increased while out of combat... BUT you can't move while in combat. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1190029623493398668/ReminiscencePrism.png?ex=65c53a73&is=65b2c573&hm=0d790807198ac8168b7030a461d220bc82b5c92b142846d8f3d2941255a3b099&=&format=webp&quality=lossless" width="100"/> | Reminiscence Prism | Gain 20% stage transition crit chance.... BUT your critical strike chance is set to 0 for the stage upon stage transition crit. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1201959329620840448/VesselOfHeresy.png?ex=65cbb6db&is=65b941db&hm=c8ac570e8cdc7d5807ec75dab1bf3235081f37069579597cf162c9ee468eb4b5&=&format=webp&quality=lossless" width="100"/> | Vessel of Heresy | Become Heretic. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053386272363790386/WindFluxPauldron.png" width="100"/> | Wind Flux Pauldron | Double your movement speed... BUT halve your health. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111928169140355/YHJ.png" width="100"/> | Yhjtumgrhtfyddc | Gain every buff... BUT gain every debuff. |
|  | --- |  |
|  | Void White Items |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111928714395790/BarrierStone.png" width="100"/> | Barrier Stone | Gain a miniscule temporary barrier on hit. Does nothing on the first stack because it's total dogshit. Corrupts all Barrierworks. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111929234497646/FortifiedFlask.png" width="100"/> | Fortified Flask | Receive instant barrier at low health. Consumed on use. Corrupts all Power Elixirs. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053437138282229821/PluripotentSteak.png" width="100"/> | Pluripotent Bison Steak | Gain +25% max health. Taking damage randomizes your inventory. Corrupts all Bison Steaks. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051484520605569024/Recursion.png" width="100"/> | Recursion | Does nothing. Corrupts itself. |
|  | --- |  |
|  | Void Green Items |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111929750405163/AncientAxe2.png" width="100"/> | Ancient Axe | Guaranteed 'Critical Strikes' against low health enemies. Corrupts all Old Guillotines. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1048689961962049587/ClaspingClaws.png" width="100"/> | Clasping Claws | Pull enemies towards you on hit. Corrupts all Boxing Gloves. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111930480205864/ExplorersTorch.png" width="100"/> | Explorer's Torch | Chance to ignite on hit. Corrupts all Ignition Tanks. |
|  | --- |  |
|  | Void Red Items |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053355804377493554/BisonSkull2.png" width="100"/> | Bison Skull | Gain 1 barrier on kill. Corrupts ALL healing items. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1122839484560588871/FreeWinFriday.png" width="100"/> | Free Win Friday | Win. Corrupts all Spare Drone Parts. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111930933182574/TubOfBart.png" width="100"/> | Tub Of Bart | Increases agility. Corrupts all Tubs of Lard. |
|  | --- |  |
|  | Void Lunar Items |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1190025383450517614/BlueWhip.png?ex=65c53681&is=65b2c181&hm=29a255e0b246c07b169e3800881f34b9716a9dccfc06fabc0a5c9c68b9e061d7&=&format=webp&quality=lossless" width="100"/> | Blue Whip | Your movement speed is tripled while in combat... BUT you can't move while out of combat. Corrupts all Purple Whips. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111931373604904/ExpressionOfTheImmolated.png" width="100"/> | Expression of the Immolated | Dramatically reduce Skill cooldown... BUT they automatically activate. Corrupts all Gestures of the Drowned. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111931843362967/FormlessSand.png" width="100"/> | Formless Sand | Double your health... BUT halve your damage. Corrupts all Shaped Glasses. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1122844532556435567/UranialRaegis.png" width="100"/> | Uranial Raegis | Randomly create a Ward of Barrier that grants temporary barrier to ALL characters while in its radius. Corrupts all Mercurial Rachises. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1053354169546850345/VoidFluxPauldron.png" width="100"/> | Void Flux Pauldron | Randomizes stats, teams, and skills periodically. Corrupts all Lunar Pauldrons. |
|  | --- |  |
|  | Void Boss Items |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1048320363139977306/CorruptsAllShatterspleens.png" width="100"/> | Corrupts all Shatterspleens.  | Corrupts all Shatterspleens. |
|  | --- |  |
|  | Equipment |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1045826628124676238/TheAegisfunder.png" width="100"/> | The Aegisfunder | Unleash a rapid-fire barrage of Aegises that give barrier on hit. Consumes 1 Aegis for every second of firing. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111932384419980/BloodGamble.png" width="100"/> | Blood Gamble | Fire a singular missile with a chance to die. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034111027777908877/BottledMetamorphosis.png" width="100"/> | Bottled Metamorphosis | Transform into another survivor |
|  | --- |  |
|  | Lunar Equipment |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034112629133815879/lunarfunder.png" width="100"/> | The Crowdfunder 2 | Unleash a rapid-fire barrage of high-damage lunar shards. Consumes Lunar Coins. |
|  | --- |  |
|  | Boss Equipment |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034112629754564719/VoidDonut.png" width="100"/> | Void Donut (Voidlingling) | Briefly unleash a devastating void laser. |
|  | --- |  |
|  | Elite Equipment |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1190024424955588648/RushingEliteAffix.png?ex=65c5359c&is=65b2c09c&hm=868fdf6d35e8bdd3fe01a2324b6bea9b082f9a22353864554884d878db3f56f6&=&format=webp&quality=lossless" width="100"/> | Blessing of Woolie (Rushing Elite) |  |
| <img src="https://cdn.discordapp.com/attachments/980549982883037286/1058562825854926970/BackupAspect.png" width="100"/> | Secret Compartment (Compartmentalized Elite) | Become an aspect of backup. |
|  | --- |  |
|  | Enemies |  |
|  | Standard |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034112630945742859/LivingSuppressiveFire.png" width="100"/> | Living Suppressive Fire | A flying fodder enemy capable of rapidly shooting down any foes in its wake. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1046098591812427888/The.png" width="100"/> | The | A strange smirking cat-like creature from the Cracked Coalition, Thes may not have much health or hit very hard, but they are basically immortal. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034112631444877322/Voidlingling.png" width="100"/> | Voidlinglinglingling | Literally just Voidling as a fodder enemy. |
|  | Minibosses |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1034112630417281115/CrackedPest.png" width="100"/> | Cracked Pest | An extremely dangerous flying Miniboss that shoots a spread of 5 exploding spitballs. Its mega-swag shades indicate that it's not to be messed with. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1048674818356158514/CrackedVermin.png" width="100"/> | Cracked Vermin | A blazing fast Miniboss that rapidly stomps the ground as it chases you. They prize their dripped-as-fuck Jordans, so try telling them that they are fake. |
| <img src="https://cdn.discordapp.com/emojis/1168289763959242793.gif" width="100"/> | Freddy Fastbear | ar ar ar ar ar ar ar ar ar ar |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1046100239112753172/IonSurger.png" width="100"/> | Ion Surger | A pair of electric balls that constantly launch themselves into the air with a surge of ions. The balls stay even after death. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034112631444877322/Voidlingling.png" width="100"/> | Voidlinglingling | Literally just Voidling as a Miniboss. |
|  | Champions |  |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1046111086841188393/CrowdfunderWoolie.png" width="100"/> | Crowdfunder Woolie | This slow but powerful behemoth is a true menace, capable of shredding your healthbar to bits in a split second with its six mounted Crowdfunders. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1046106725490638858/GummyBeetleQueen.png" width="100"/> | Gummy Beetle Queen | Gummy Beetle Queen. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1046109698513961070/Providence.png" width="100"/> | Providence | Thanks to the disturbances in the timeline caused by Cracked Emoji's influence, Providence has finally returned, now as a Stage 3 Teleporter boss! |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034112631444877322/Voidlingling.png" width="100"/> | Voidlingling | Literally just Voidling as a Champion. |
|  | Superbosses |  |
| <img src="" width="100"/> | Glassthrix | Residing on Petrichor V's other moon, this glassy clone of Mithrix is Cracked Emoji's most powerful subordinate and is a top enforcer of Crackedness. You do not have what it takes to take him down. Unless you cheat or smth idk. |
|  | --- |  |
|  | Artifacts |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051479621939499008/artifactofloaderon.png" width="100"/> | Artifact of Artifact | All players and monsters move at a quarter of their regular speed. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034113017035640863/artifactofblindnesson.png" width="100"/> | Artifact of Blindness | The fog is coming. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051479596522016778/artifactofcrowdfundingon.png" width="100"/> | Artifact of Crowdfunding | Passively lose gold every second. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1051479630751731814/artifactofsoleon.png" width="100"/> | Artifact of Sole | Take bleed damage while moving based on your current velocity. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1034113016591036426/artifactoffearon.png" width="100"/> | Artifact of Woolie | If you take more than 5 minutes to complete a stage, you instantly fucking die. Should've rushed harder, dumbass. |
|  | --- |  |
|  | Alternate Skills |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1058563727114391632/DoomBlast.png" width="100"/> | Doom Blast (Commando M1) | Fire a slow, but powerful spread of 20 bullets for 20x100% damage. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1058563879564755014/SharkSaw.png" width="100"/> | Shark Saw (Huntress M2) | Throw a piercing sawblade that dashes into a nearby target, dealing 150% damage and sticking to surfaces, dealing 60% bleed damage multiple times. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1104470344972112012/decoy_icon_128x128.png" width="100"/> | Explosive Decoy (Bandit Util) | Deploy a decoy that draws enemy attention for 5 seconds before exploding in a damaging blast for 200%. The decoy will explode early if it is killed. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1058564283522367488/scorch.png" width="100"/> | Welding Blast (MUL-T Util) | Fire a burst of flames that deal 800% total damage over time and incinerate enemies, causing them to return 20% of damage taken as temporary barrier and grant 25% of max health as temporary barrier upon being killed. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1058563727605116968/Entangler.png" width="100"/> | Entangler (Engineer M1) | Take manual control of your mechanical allies, giving you and them +40% movement speed and +100% attack speed, and reducing your armor by 50 while in use. Entangled allies will be disabled for 5 seconds after disengaging from Entangler. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1058563730981531698/StigmataShotgun.png" width="100"/> | Stigmata Shotgun (REX M1) | Weakens. Fires 9 pollen pellets for 9x50% damage. Costs 5% HP. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1058563731430330398/HephaestusShotgun.png" width="100"/> | Hephaestus Shotgun (Captain M1) | Charge up a blast of rapid fire incendiary rounds for 60% damage each, inflicting ignite on hit. Bullets fired increases with charge time, but so does spread. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1058563728091664434/Magnetic_Propulsor.png" width="100"/> | Magnetic Propulsors (Railgunner Passive) | Crit chance is converted to jump height at a rate of 1% crit chance to 3% jump height. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1058564283866292345/CJI.png" width="100"/> | CJI Dumb Rounds (Railgunner M1) | Fire an extraordinarily inaccurate spread of 30 rounds per second for 100% damage each. Spread scales with field of view. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1131053002384490516/tottf.png" width="100"/> | The Only Thing They Fear (Viend Passive) | You are permanently corrupted. Gain corruption on hit. Your current health depends on your corruption at all times. Difficulty scales faster over time. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1103503405147766857/warp_icon_128x128.png" width="100"/> | War??p (Viend M2) | Launch a void urchin that sticks to surfaces and repeatedly deals 60% damage to nearby enemies. Using the skill again warps you to the void urchin, destroying it in the process. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1103503404854149120/corrupted_warp_icon_128x128.png" width="100"/> | Corrupted War??p (Corrupted Viend M2) | Launch a powerful void harpoon that teleports you on impact, telefragging nearby enemies for 2600% damage. |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1058563729354149908/Drain.png" width="100"/> | Dr??ain (Viend Special) | Rapidly drain your corruption and fire a devastating blast for 100% damage that massively scales with corruption consumed. |
| <img src="https://media.discordapp.net/attachments/1034109740978020542/1130968685411053712/VOCK_BLAST.png?width=676&height=676" width="100"/> | Corrupted Dr??ain (Corrupted Viend Special) | Root yourself temporarily, gaining a large amount of corruption. Release a barrage of devastating lasers for 320% damage each upon breaking free. |
|  | --- |  |
|  | Cracked Survivors |  |
| <img src="https://cdn.discordapp.com/attachments/1034109740978020542/1048393900106203197/CrackedCommando.png" width="100"/> | Cracked Commando | A true jack of all trades, this 32-armed monstrosity can do next to anything with his skills that are combinations of Commando's default and alternate skills. |
| <img src="" width="100"/> | Cracked Mercenary | Cursed with the knowledge of everywhere he isn't in this world so that he can know his place in it, Cracked Mercenary developed the most powerful OP mercenary build, pelting his enemies with swarms of missiles and invincibility frames. |
|  | --- |  |
|  | Other Survivors |  |
| <img src="" width="100"/> | Nemesis Healing Core | real??? |

# Contact/Feedback
Join the balls group discord server and send any suggestion or bug reports in their respective channels. You can contact me directly at monsterskinman on discord, or you can contant HIFU or pseudopulse too idk.

# Planned Content
- Actual fucking item models (we'll do that eventually... for realsies now)
- More non-shitty skill icons
- Tons of everything except stages!
- More cracked survivors!
- More alternate skills (every vanilla character will have an alternate skill for each slot)

For a full list of planned content so far, check out the GOTCE item document in the pins of the GOTCE channel, which also contains links to the other GOTCE documents (note: we've been lazy and haven't been updating these so they are a bit outdated)

# Known Issues
- The mod is still WIP, however it is still EXTREMELY EPIC!!!
- We only have placeholder models right now cry about it
- Some icons are placeholders and suck
- I currently have no plans to ever do item displays fucking cry about it
- Not all alt skills have implemented unlocks
- There are probably networking issues, so certain skills won't work in multiplayer. Everything else hopefully will though.

# Credits
- - MonsterSkinMan (Main codr, many ideas, logbook entries, playtesting, shitty placeholder skill icons and some shitty placeholder item icons, original creator)
- - Pseudopulse (Main codr, ideas, playtesting, shitty placeholder skill icons)
- - HIFU (Main codr, many ideas, item icons, playtesting)
- - EssentiallyFalse (Ideas, playtesting, some logbook entries, GOTCE ost)
- - GetterRocka (Skill icons) (Link to his art https://getterrocka.newgrounds.com/)
- - n2h4 (Logbook entries, ideas)
- - Creepz (Logbook entries)
- - smxrez (some item models that I haven't gotten around to implementing :smirk_car:)
- - RandomlyAwesome (Coding help)
- - borbo (Coding help)
- - DuhDoesNothing (Elite icons, doing nothing [duh])
- - personal shield generator (13) (providing +104% of our max hp in shield, winning videogame, logbook entries for Personal Shield Generator and Personal Shield Generator (13))
- - Dotflare (Models, ideas)
- - Dumbdazed (Playtesting, ideas)
- - Penfolder (Ideas)
- - Leaf_It (The Only Thing They Fear icon)
- - KomradeSpectre (Item template & tutorial)
- - TheMysticSword (Manuscript code)
- - Shrike (Original spikestrip chan image) (Link to his art https://x.com/shrikethebird?s=20)
- - Thingw (Doom Blast icon)

