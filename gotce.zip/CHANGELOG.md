# 1.4.1 Patch Nodes
- fixed issue with cracked merc icons
- fixed glassthrix still having ramps
- fixed cracked merc m2 canceling itself
- fixed bug where music didnt play

# 1.4.0 Patch Notes - Wave 4: The Balls Expansion
- WOOOOO WAVE 4 BABY!
- New cracked survivor: Cracked Mercenary
- New final boss: Glassthrix
- New gamemode: Crackclipse
- New music, courtesy of essentiallyfalse
- New items: Leviathan Larva,  Personal OSP Generator, Seething Opioids, Teacher's Pet, Lucky Day, Squid Ink Spaghetti, Eternal Echo, Imposter's Blade, Purple Whip, Reminiscence Prism, Vessel of Heresy, Blue Whip
- New elite type: Rushing
- Voidling family enemies FINALLY spawn now. fucking hell
- bug fixes probably
- Suppressed the Cracked Emoji

# 1.3.3 Patch Notes
- Fixed unintentional NREs
- Fixed typos and shit
- Suppressed the Cracked Emoji

# 1.3.2 Patch Notes
- "minor" update
- mostly just pushing out fixes because ghor is streaming gotce but I'm too lazy to disable new content
- Added 15 new items: Bloody Shank, Bone Armor, Small Spinny, Billie Jean, LtG Missile Mk. 1, OP Merc Build, Retrobauble, Scathing Embrace, Speedy Finger, Trickle-down Bleedonomics, Lotus, LtG Missile Mk. 2, Oni Hunter's Sword, Zaniest Tree, Pebbsi Zero
- New icons for French Horn, Dripping Camera, and Summertime Soda
- Added 1 new enemy: Freddy Fastbear
- Added 1 "new" "playable" "survivor": Nemesis Healing Core
- The and Cracked Commando now have proper running animations and stuff.
- Fixed hitboxes for melee enemies (ie The and Providence [You are not prepared for Providence's true hitboxes :Fear:])
- Buffed Analytical Aegis to give 12 (+19 per stack) barrier.
- Buffed Animal Head to reduce skill cooldowns by 5% (+5% per stack).
- Buffed Weeping Aegis to give 15 (+14 per stack) shield.
- Buffed HIFU's Racecar to give 3 Backup Mags on each pickup.
- Buffed Missile Guidance System to fire 2 (+2 per stack) missiles on FOV crit.
- Buffed Corrupted Shard chance to """do nothing""" down to 0.5%.
- Buffed the Aegisfunder to deal 25000% damage.
- Nerfed Sigma Grindset to give 0.5hp/s (+0.5hp/s per stack) regen.
- Nerfed Skull Key to drop 3 (+3 per stack) items.
- Nerfed Extremely Unstable Tesla Coil damage to 0.01%. Also it's supposed to double stack count every few seconds it's intentional trolling.
- Fixed Barrier Insurance not working.
- Fixed Pluripotent Bison Steak multiplying item count.
- Fixed Healing Scrap not working.
- Fixed Corrupted Shard """doing nothing""" way too quickly (how quickly...)
- Fixed Bottled Metamorphosis icon.
- Fixed / icon.
- Added missing lore entries.
- Fixed / stats.
- Fixed some item descriptions.
- Fixed Suppressive Nader on hit effect not working.
- Fixed some other stuff probably.
- Suppressed the Cracked Emoji


# 1.3.1 Patch Notes
- Fixed missing brundle
- Suppressed the Cracked Emoji

# 1.3.0 Patch Notes - Wave 3.5: A Crack In Time
- Yeah we're doing a half wave
- Still added more content than the entirety of some other mods lmao goes hard
- Suppressed Cracked Emoji.
- +16 items and +1 equipment
- Well technically -1 item too since we turned bottled metamorphosis into an equipment
- Including equips, the total item count is now 100. We are the first item mod to reach 100 items let's fucking joe!
- Crown Prince noew becomes Crown Prince.exe upon being consumed, allowing it to retain the debuff even after all 50 lives are used up.
- Fixed an oversight with Shrines of Disposability that caused them to never stop firing
- Using Shrine of Disposability while the missiles are in use no longer adds another stream, and the missiles are instead added to the current stream's backlog. DML shrine is supposed to be shit, so this is one of the things we did to nerf it.
- Interactables can now be disabled in the configs. About fucking time.
- Zany Soup now doubles more items
- Void Donut removed from normal equipment pool for real for real for real this time... hopefully.
- Balls can no longer be scrapped nor can it be taken by mithrix. Balls will stay.
- Added a logbook entry for Turbulent Defibrillator because I forgor
- New crit types (Critcal Deaths and Critical Camera Rotations)
- Some other bugfixes probably (hopefully)
- Suppressed the Cracked Emoji

# 1.2.5 Patch Notes
- Fixed a bug that caused on-kills to be fake.
- Fixed some bugs relating to war crimes.
- Nerfed the melee hitbox increase from the AOE effect stat to be more reasonable.
- Changed Amber Rabbit to no longer exponentially increase items on stage crit. While this is a nerf, the item is powerful enough for that to not matter and it will also hopefully help prevent Amber Rabbit crashing the game as often.
- Fixed bugs related to visual effects not appearing.
- Thes are now only stunned if an attack would deal damage equal to or higher than the The's maximum health.
- Thes now receive heavy knockback upon being stunned
- Living Suppressive Fires now apply the weaken debuff on hit and have slayer, allowing them to potentially actually do something.
- Buffed the base damages on Living Suppressive Fire and Cracked Vermin.
- Added various monsters to more stages.
- Various other changes and bugfixes.
- Suppressed the Cracked Emoji

# 1.2.4 Patch Notes
- Added images to the readme for skills because the maximum readme size was increased.
- Changelogs are no longer kept in the readme because of other thunderstore updates, and we also added back the old hotfix patches
- Anyways on to actual gotce stuff
- Fixed Corrupted Warp damage being way, way, way higher than intended lmao
- Nerfed Hephaestus Shotgun damage from 60% per bullet to 30% per bullet
- Nerfed Doom Blast proc coefficient from 1.0 to 0.75 and changes its damage falloff type from none to buckshot
- Nerfed Welding Blast cooldown from 8 seconds to 15 seconds and halved the barrier gain from the incinerated debuff
- Fixed the problem where the config presets for disabling certain types of items didn't properly work
- Mildly nerfed Providence's damage
- Buffed The's damage
- Buffed Living Suppressive Fire
- Nerfed Cracked Pest damage and speed
- Buffed Cracked Vermin speed
- Nerfed Ion Surger health
- Actually fixed Void Donut appearing in equipment barrels for real this time hopefully
- Suppressed the Cracked Emoji

# 1.2.3 Patch Notes
- Fixed inaccurate skill descriptions
- Fixed style errors in the logbook and shit
- Nerfed the damage of Doom Blast from 20x100% to 20x90%
- Buffed the damage of Corrupted Warp from 700% to 1500%
- Fixed Clasping Claws not corrupting Boxing Gloves
- Fixed Corrupts all Shatterspleens not actually corrupting Shatterspleen :skull:
- Fixed configs not working
- Clarified description for The Only Thing They Fear
- Fixed unlocks for Shark Saw and The Only Thing They Fear
- The radius of the explosion for uncorrupted Drain now increases with corruption consumed
- Suppressive Nader now actually has phase round lightning
- Temporarily removed old hotfix patches from the readme to save space.
- Suppressed the Cracked Emoji

# 1.2.2 Patch Notes
- Fixed the readme for real this time
- Suppressed the Cracked Emoji

# 1.2.1 Patch Notes
- Dope Dope now multiplies attack speed by 12 and divides damage by 12 per stack. It also no longer gives shield.
- Fixed an issue with the networking hook
- Fixed a bug related to Lunar Seers
- Added missing icons
- Fixed the Readme. Now you can see all of the new content!
- Fixed Cracked Commando's character select description.
- Suppressed the Cracked Emoji

# 1.2.0 Patch Notes - Wave 3: The Crackening Part 1
- Added over 30 new items, bringing the item count all the way up to a staggering 88, including equipments.
- Added 8 new enemies, for a total of 11! This means that GOTCE is now the largest enemy mod currently.
- Added 12 new alt skills to a variety of survivors. Our goal with these alt skills is to generally make somewhat well-made alt skills to fill in slots that don't have alts, like commando m1 or all of viend. Of course, not all of these skills will be serious, like for railgunner and lodr because fuck them lmao
- Added a new tier 1 elite called Compartmentalized Elites. They have 3 extra charges and 50% reduced cooldown on their secondary skill (if they have one), and disable your secondary skill on hit for a few seconds.
- Added 2 new shitty artifacts
- Added the new Cracked Commando survivor!
- Fixed an oversight that caused the Wave 2 enemies to spawn much less frequently, or not at all in the case of Living Suppressive Fire. Whoops lmao. I guess this technically means that you're getting 11 new enemies because the 3 from Wave 2 were basically fake.
- New mechanic: Critical Sprints - Every time you initiate a sprint with any amount of Sprint Crit Chance, you will critically sprint, doubling your speed.
- New mechanic: AOE Effect - AOE effect increases the sizes of blast attacks, orb ranges, and overlap attacks (aka melee hitboxes). Bang Snap has been reworked to give you +2 AOE effect instead of increasing the size of blast attacks by 2 meters. This means that Bang Snap is significantly more useful.
- New mechanic: War Crimes - Various actions will cause you to commit a war crime, with your most recent one being tracked. These include using certain skills, using certain items, or killing mending cores, which specifically counts as killing medical personnel.
- Nerfed Cracked Pest aoe and damage
- Added configs for enemies
- Added config presets that disable all items with certain item tags, namely unstable (lag and crashing), bullshit (extremely stupid items), and a few others I forgor about
- Implemented unlocks for alt skills (most of them at least, we haven't finished them all). They can be disabled in the configs in order to not have to unlock the skill.
- The void lunar tier is actually real now and has a custom background color in the logbook.
- Same goes for the boss equipment tier.
- With the proper implementation of the boss equip tier, Void Donut will no longer appear in the normal equipment pool. No more Void Donut from an equipment barrel for you!
- Drastically increased measures against any slab revival. It will fucking stay dead. Fuck the slab.
- Fixed some bugs here and there, probably.
- Also probably some minor buffs and nerfs, maybe? I kinda forgor tbh.
- Hello World now properly throws NREs every frame, instead of once every recalcstats
- Monster's Visage now has a range indicator.
- All items are now able to be disabled in the config.
- Pretty sure Pale Ale is real now?
- And more!
- Download the fucking mod already jesus
- Fun fact: 100% is extremely low. This is related to a secret somewhere, unless it was removed.
- Suppressed the Cracked Emoji

# 1.1.1 Patch Notes
- Added a new red item (Gabe's Shank)
- Healing scrap is now actually reusable once per stage
- Fixed a bug with Crowdfunder 2 where its downside applied once every frame instead of once every second.
- Updated readme with images and shit.
- Fixed an issue that caused Voidlingling and Void Donut to not appear in the logbook.
- Buffed Cracked Pest and Voidlingling movement speed.
- Suppressed the Cracked Emoji

# 1.1.0 Patch Notes - Wave 2: #GotceSWEEP
- Added a bunch of new items, bringing the total up to 51!
- Added Stage Transition Crits and FOV Crits.
- Introduced 2 new enemies and 1 new boss (the new boss might not be properly implemented yet idk)
- Updated nearly every icon!
- Implemented placeholder item models until we make real models.
- Removed the lunar slab (reroller) from the bazaar because I fucking hate it so much it is an atrocity of game design.
- Suppressed the Cracked Emoji

# 1.0.3 Patch Notes
- Fixed Formless Sand being in the White item pool.
- Suppressed the Cracked Emoji

# 1.0.2 Patch Notes
- Added new artifact (Artifact of Loader)
- Buffed Spikestrip Chan NFT to give a +100% stat buff instead of +50%
- Updated readme to contain a list of content
- Fixed a bug where fall damage didn't exist.
- Fixed a bug that caused Shrines of Blood and Void Cradles to be unusable.
- Fixed an issue with Blood Gamble that caused it to constantly throw NREs.
- Fixed Grandfather Clock's description
- Artifact of Woolie now has an icon to show when it's disabled.
- Suppressed the Cracked Emoji

# 1.0.1 Patch Notes
- Fixed readme
- Suppressed the Cracked Emoji
  
# 1.0.0 Patch Notes - Wave 1: Rise of The BALLS
- The mod exists
- Suppressed the Cracked Emoji

